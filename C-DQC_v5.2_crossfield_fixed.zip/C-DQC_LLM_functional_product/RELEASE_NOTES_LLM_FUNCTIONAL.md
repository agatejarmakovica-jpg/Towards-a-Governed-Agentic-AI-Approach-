# C-DQC LLM Functional Product

This build keeps the v5.0 product structure and adds a functional LLM contract-construction layer.

Implemented behavior:

- `ContractAdvisorLLM` proposes contract fields before assessment.
- The LLM is used for column semantics, descriptions, measurement-unit suggestions, sensitivity suggestions, controlled vocabularies, safe canonical mappings, and cross-field rule candidates.
- The LLM cannot approve the contract, compute metrics, change data, change verdicts, invent license, or invent provenance.
- A deterministic verifier blocks unsafe mappings, especially mappings from one already valid category to another valid category.
- Dataset and clean reference are blocked if the same file is uploaded for both inputs.
- The UI keeps the existing v5.0 layout, replacing the decorative SemanticAdvisor with functional LLM-assisted contract construction.

Validation performed:

- Full pytest suite: 32 passed.
- Added tests for blood-type mapping safety and identical dataset/reference blocking.
- Smoke test completed on `healthcare_messy_data(2).csv` with `healthcare_cleaned.csv` using deterministic fallback mode.

## Update: strict structured outputs for the LLM contract advisor (API integration fix)

Problem addressed:

- `400 invalid_json_schema`: the previous Pydantic output model contained a `dict[str, str]` field (`canonical_mapping`), which produces `additionalProperties` in the generated JSON schema. OpenAI strict structured outputs require `additionalProperties: false` and `required` to cover every property, so the request was rejected.
- After a temporary switch to unconstrained JSON mode, the LLM drifted structurally (boolean operation flags and nested example dicts inside `canonical_mapping`, cross-field rules without `rule_id`/`left_column`/`operator`, severity `error`, object-shaped `unresolved_questions`), producing 34 Pydantic validation errors at parse time.

Implemented behavior:

- New strict-compatible wire models (`WireAdvisorOutput` and submodels): no dict fields, `canonical_mapping` is an explicit list of `{raw_value, canonical_value}` entries, `unresolved_questions` are `{column, question}` objects, cross-field rules carry a closed operator and severity vocabulary. The wire schema is verified strict-compliant by a regression test (`required` equals `properties` at every level; `additionalProperties: false` everywhere).
- Primary call path is `client.responses.parse(..., text_format=WireAdvisorOutput)`: structural validity is enforced by constrained decoding at generation time, so the shape-drift error class is impossible by construction.
- Deterministic conversion `_wire_to_internal()` maps the wire shape to the unchanged internal models (confidence clamped to [0, 1]; empty entries dropped).
- Audited fallback chain for SDK/model combinations without strict support: JSON-object mode, then plain-text JSON extraction. The fallback normalizer coerces observed drift where a safe interpretation exists and drops everything else with per-item reasons recorded under `llm_audit.normalizer_dropped`. Operation flags are never reinterpreted as data transformations: the contract action space remains closed.
- LLM-proposed cross-field rules can never enter as `confirmed`; they are downgraded to `supported` at most. Human approval remains the only authorization boundary.
- `llm_audit` now records `api_mode` (`responses_parse_strict` / `responses_json_object` / `responses_json_text_fallback`), `structured_output_enforced`, and `fallback_errors`, so every report states whether structural validity was guaranteed or normalized.

Validation performed:

- Full pytest suite: 37 passed (5 new tests: strict-schema compliance, wire-to-internal conversion, normalizer regression reproducing the exact production drift payload, strict-parse call path, JSON-object fallback path).
- End-to-end smoke with a mocked strict response: safe mapping `AB - -> AB-` applied; unsafe valid-to-valid mapping `A+ -> A-` blocked by the deterministic verifier; LLM-supplied license blocked; `api_mode = responses_parse_strict`.

## Update: repeated-run reliability fix (Streamlit session state)

Problem addressed: on a second assessment run in the same session, results could become unavailable or the run could execute under the wrong contract. Two verified root causes in `app.py` (no hardcoded values were involved — confirmed by codebase audit):

1. Destructive ordering: the shared `workspace/assessment` directory was deleted *before* `run_assessment` executed. Any failure in the second run (e.g., the byte-identical dataset/reference guard) left the session pointing at an already-deleted directory, so rendering the previous result crashed on every rerun and the assessment appeared "stuck after the first test".
2. Silent contract fallback: with no new contract uploaded, the contract approved earlier in the session was reused without any dataset match check, so a second dataset could be assessed under the first dataset's contract (column mismatch was only a manifest warning).

Implemented behavior:

- Every run writes to a unique timestamped output directory; previous runs are never deleted, and session pointers are updated only after a fully successful run.
- Session-approved contracts are reused only after an explicit column-set match against the currently uploaded dataset; a mismatch raises a clear error instead of silently proceeding. Explicitly uploaded contracts keep pipeline behavior, and contract warnings from the manifest are now surfaced in the UI.
- Stale results whose directory no longer exists (e.g., after a workspace reset in Colab) show an explanatory message instead of crashing.
- The human-review step uses the same unique-directory pattern.

Validation: headless double-run simulation (successful run → failed run → successful run) confirms the first run's outputs remain intact and readable after a failed re-run, and runs land in distinct directories. Full pytest suite: 37 passed.

## Update: cross-field rule evaluator typed comparison fix

Problem addressed: cross-field rules were evaluated on raw values, producing lexicographic string ordering ("31.0" <= "130" is False because "3" > "1"), and the exception path counted TypeErrors as violations. On a 55,500-row healthcare dataset this produced 103,638 reported violations where ground truth was 2,532 (~97.6% false positives), depressed cross_field_consistency_rate to 0.468 (true: 0.987), and inflated the human-review queue by ~108,000 rows.

Implemented behavior: operands are coerced to the left column's contract role before comparison (numeric -> to_numeric, date -> to_datetime, otherwise trimmed string). Values present but uncoercible in the declared role are counted as cross_field_not_evaluable (reported separately in AccuracyAgent metrics), never as violations; a rule constant uninterpretable in the role marks the whole rule not evaluable. Evidence-status separation added: only rules with severity "confirmed" contribute to confirmed contract-violation cells; candidate/supported rule findings stay in the review queue.

Validation: regression test with lexicographic and uncoercible operands (38 tests pass); full re-run on the 55,500-row dataset reproduces the independently computed ground truth exactly (r1=1572, r2_max=873, r3=87; consistency 0.9869; not_evaluable 1877). Reference-based validated accuracy is unchanged (0.8327), confirming the reference path was never affected.
