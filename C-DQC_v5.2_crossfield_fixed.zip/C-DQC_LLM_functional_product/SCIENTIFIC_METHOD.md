# Scientific method

## Quality dimensions

C-DQC assesses completeness `C`, accuracy or validity evidence `A`, and reuse readiness `R`.

```text
DQI = 0.30*C + 0.40*A + 0.30*R
```

In `CONTRACT_ONLY` mode, `A` is contract-validity support and the result is named `DQI_support`. In validated modes, `A` is based on clean-reference accuracy or manifest-based detection evidence and the result is named `DQI_validated`.

## Completeness

```text
C = 1 - confirmed_missing_cells / assessable_cells
```

Criticality-weighted completeness uses contract-defined column weights. Candidate missingness is reported separately and is not counted as confirmed missingness.

Imputation methods are evaluated by masking observed values and comparing reconstructed values with known values. Metrics are emitted only when the validation sample is sufficient.

## Accuracy and validity

Contract-driven checks include parsing, ranges, approved categories, formats, dates, uniqueness, and cross-field constraints. Statistical anomaly methods produce candidates.

With a clean reference, rows are aligned by approved primary key. Positional alignment is available only under the contract alignment policy and is explicitly reported. Metrics include exact and tolerance-adjusted cell accuracy, per-column accuracy, row exact match, numeric MAE/RMSE, and categorical macro-F1.

With a corruption manifest, the system calculates TP, FP, FN, TN, precision, recall, specificity, false-positive rate, F1, MCC, and per-issue-type metrics. Reference mismatch findings are evidence findings and are not scored as detector false positives against a corruption manifest.

## Reuse readiness

The reuse score is a contract-weighted combination of documentation, schema, standardization, privacy, and machine readability. Blocking conditions are evaluated independently from the numeric score.

## HITL and before/after validation

Only named human-approved executable proposals are applied. The source is never modified. All three agents are rerun on the curated copy under the same contract and evidence mode. The system reports `C_before`, `C_after`, `A_before`, `A_after`, `R_before`, `R_after`, `DQI_before`, `DQI_after`, and deltas.

## Experimental validation

The built-in repeated benchmark uses deterministic seeds, controlled defect injection, four methods, bootstrap 95% confidence intervals, Wilcoxon paired tests, rank-biserial effect size, and per-issue-type results. External generalization must be evaluated separately on the three selected research datasets.
