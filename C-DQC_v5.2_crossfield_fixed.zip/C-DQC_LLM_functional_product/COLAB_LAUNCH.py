"""Stable Google Colab launcher for the C-DQC Streamlit product.

Colab use:
1. Upload this file to a blank Colab notebook.
2. Run: %run COLAB_LAUNCH.py
3. Upload C-DQC_v5.0_scientific_product.zip when requested.
4. Open the printed trycloudflare.com URL.
"""
from google.colab import files
from IPython.display import HTML, display
from pathlib import Path
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile

print("Upload C-DQC_v5.0_scientific_product.zip")
uploaded = files.upload()
zip_files = [name for name in uploaded if name.lower().endswith(".zip")]
if len(zip_files) != 1:
    raise ValueError("Upload exactly one C-DQC product ZIP file.")

zip_name = zip_files[0]
work_dir = Path("/content/cdqc_v50")
if work_dir.exists():
    shutil.rmtree(work_dir)
work_dir.mkdir(parents=True)

with zipfile.ZipFile(Path("/content") / zip_name) as archive:
    archive.extractall(work_dir)

project_roots = [
    path.parent
    for path in work_dir.rglob("app.py")
    if (path.parent / "requirements.txt").exists()
]
if not project_roots:
    raise RuntimeError("The ZIP does not contain app.py and requirements.txt.")

project_root = project_roots[0]
os.chdir(project_root)
print("Project:", project_root)

subprocess.check_call([
    sys.executable,
    "-m",
    "pip",
    "install",
    "-q",
    "-r",
    str(project_root / "requirements.txt"),
])

subprocess.run(["pkill", "-f", "streamlit"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run(["pkill", "-f", "cloudflared"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

streamlit_log_path = Path("/content/cdqc_streamlit.log")
streamlit_log = streamlit_log_path.open("w")
subprocess.Popen(
    [
        "streamlit",
        "run",
        str(project_root / "app.py"),
        "--server.port",
        "8501",
        "--server.address",
        "0.0.0.0",
        "--server.headless",
        "true",
    ],
    cwd=project_root,
    stdout=streamlit_log,
    stderr=subprocess.STDOUT,
)

for _ in range(90):
    try:
        urllib.request.urlopen("http://127.0.0.1:8501/_stcore/health", timeout=2)
        break
    except Exception:
        time.sleep(1)
else:
    streamlit_log.close()
    print(streamlit_log_path.read_text(errors="ignore"))
    raise RuntimeError("Streamlit failed to start.")

cloudflared_path = Path("/content/cloudflared")
urllib.request.urlretrieve(
    "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
    cloudflared_path,
)
cloudflared_path.chmod(0o755)

tunnel_log_path = Path("/content/cdqc_cloudflared.log")
tunnel_log = tunnel_log_path.open("w")
subprocess.Popen(
    [
        str(cloudflared_path),
        "tunnel",
        "--url",
        "http://127.0.0.1:8501",
        "--no-autoupdate",
    ],
    stdout=tunnel_log,
    stderr=subprocess.STDOUT,
)

public_url = None
for _ in range(120):
    time.sleep(1)
    text = tunnel_log_path.read_text(errors="ignore") if tunnel_log_path.exists() else ""
    match = re.search(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", text)
    if match:
        public_url = match.group(0)
        break

if not public_url:
    print(tunnel_log_path.read_text(errors="ignore"))
    raise RuntimeError("The public C-DQC URL could not be created.")

print("\nOPEN C-DQC:")
print(public_url)
display(HTML(
    f'<a href="{public_url}" target="_blank" '
    'style="display:inline-block;padding:14px 22px;background:#2563eb;color:white;'
    'font-size:18px;font-weight:700;text-decoration:none;border-radius:8px;">'
    'OPEN C-DQC</a>'
))
