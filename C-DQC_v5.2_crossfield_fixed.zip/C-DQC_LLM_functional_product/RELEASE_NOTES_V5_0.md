# C-DQC v5.0 release notes

- Replaced shared issue filtering with three independent scientific agents.
- Added evidence modes and metric availability states.
- Integrated clean-reference comparison into AccuracyAgent.
- Added primary-key and controlled positional reference alignment.
- Added role-driven parsing, generic cross-field rules, and anomaly ensembles.
- Added masked-value imputation evaluation in CompletenessAgent.
- Added computed reuse and machine-readability metrics.
- Prevented dirty observed categories from automatically becoming approved values.
- Added grouped HITL review and same-evidence before/after reassessment.
- Added optional OpenAI SemanticAdvisor without deterministic authority.
- Preserved the prior Streamlit, CLI, Colab, and bundle workflow.
