# Results summary

## Automated validation

- 30 automated unit and integration tests passed.
- Streamlit health endpoint returned `ok`.
- The built wheel imported as version `5.0.0` and the CLI entry point passed a smoke test.
- A strict approved-contract assessment with clean reference and corruption manifest generated all required scientific outputs.

## Controlled repeated benchmark

Design: 30 deterministic runs, 200 clean rows before duplicate injection, typed cell/row/column evaluation, four methods, seeds 1000-1029, bootstrap 95% confidence intervals, and paired Wilcoxon comparisons.

| Method | Precision mean (95% CI) | Recall mean (95% CI) | F1 mean (95% CI) |
|---|---:|---:|---:|
| C-DQC v5 | 0.983 (0.978-0.987) | 0.838 (0.753-0.918) | 0.887 (0.828-0.941) |
| Naive rules baseline | 0.945 (0.925-0.964) | 0.762 (0.696-0.824) | 0.828 (0.785-0.870) |

Against naive rules, mean F1 difference was 0.0586, Wilcoxon p=0.000191478, paired rank-biserial effect=0.655, and Cohen dz=0.922.

## Strict reference and manifest assessment

- contract status: approved
- evidence mode: REFERENCE_AND_MANIFEST
- DQI support: 0.9645
- DQI validated: 0.9528
- tolerance-adjusted reference accuracy: 0.9461
- manifest precision: 0.9932
- manifest recall: 0.9299
- manifest F1: 0.9605
- manifest MCC: 0.9606

## Claim boundary

The controlled benchmark establishes implementation behavior under known injected defects. External generalization must be tested on the three selected research datasets with approved contracts and controlled references or corruption manifests.
