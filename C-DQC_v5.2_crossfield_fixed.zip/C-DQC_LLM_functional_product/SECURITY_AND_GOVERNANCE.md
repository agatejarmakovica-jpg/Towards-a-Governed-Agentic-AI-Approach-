# Security and governance

The deterministic three-agent assessment runs without an external API. The optional OpenAI SemanticAdvisor is disabled by default and has no authority to change data, issues, metrics, or verdicts.

Included controls:

- supported file-type allowlist;
- approved-contract strict mode;
- SHA-256 source verification;
- immutable source snapshot;
- confirmed, supported, and candidate evidence separation;
- no automatic candidate actions;
- named reviewer requirement;
- high-risk action block;
- explicit medium-risk override;
- protected columns;
- grouped and cell-level HITL review;
- separate curated output;
- complete run manifest and agent trace;
- API key excluded from logs, contracts, and bundles;
- no raw rows or direct-identifier values sent to SemanticAdvisor.

The application does not itself provide authentication, encryption at rest, organizational authorization, or legal permission to process personal data. These controls belong to the deployment environment.
