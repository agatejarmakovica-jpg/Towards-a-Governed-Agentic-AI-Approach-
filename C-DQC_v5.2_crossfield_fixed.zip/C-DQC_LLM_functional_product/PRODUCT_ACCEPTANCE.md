# Product acceptance status

## Implemented and tested

- exactly three independent specialist agents
- contract-driven behavior without dataset-specific agent rules
- numeric validation independent of Pandas dtype
- clean reference used inside AccuracyAgent
- manifest-based precision, recall, F1, MCC, specificity, and false-positive rate
- support and validated metrics kept separate
- unavailable metrics marked `NOT_COMPUTABLE`
- computed machine-readability indicators
- observed, suggested, and approved category values separated in contract drafts
- grouped HITL review plus cell-level overrides
- separate curated output and three-agent reassessment
- before/after C, A, R, and DQI comparison
- optional advisory OpenAI integration with no metric or data authority
- immutable input hash verification
- Streamlit, CLI, ZIP bundle, wheel, and Colab launcher

## Executed validation

- automated unit and integration test suite
- 30-run deterministic synthetic benchmark
- bootstrap 95% confidence intervals
- paired Wilcoxon comparisons and effect sizes
- clean-reference and corruption-manifest assessment
- Streamlit health check
- wheel build and installation smoke test

## Scope boundary

The included benchmark proves implementation behavior under controlled known defects. It does not by itself prove external generalization. Final research evidence on three independent open datasets must be produced by running the included protocol with those datasets, approved contracts, and references or injected corruption manifests.
