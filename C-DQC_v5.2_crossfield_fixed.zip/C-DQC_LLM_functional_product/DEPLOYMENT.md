# Deployment

## Local

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## Google Colab

Use the included `COLAB_LAUNCH.py`. It preserves the working Streamlit plus Cloudflare tunnel method. Upload the launcher to a blank Colab notebook, run `%run COLAB_LAUNCH.py`, upload the product ZIP, and open the printed URL.

## Docker

```bash
docker build -t cdqc-product:5.0 .
docker run --rm -p 8501:8501 cdqc-product:5.0
```

## Replit

```bash
streamlit run app.py --server.address=0.0.0.0 --server.port=3000
```

## Operational controls

Do not expose identifiable data through an unauthenticated public deployment. Keep the API key and datasets outside source control. Use organizational access control, encryption, retention, and legal-basis controls appropriate to the processing environment.
