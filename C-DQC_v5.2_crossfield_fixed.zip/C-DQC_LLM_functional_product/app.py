from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
import tempfile
from uuid import uuid4

import pandas as pd
import streamlit as st

from cdqc_core.contract import DatasetContract, approve_contract, generate_draft_contract, save_contract
from cdqc_core.llm_contract_advisor import LLMContractAdvisorConfig, generate_llm_assisted_contract
from cdqc_core.io import read_table
from cdqc_core.pipeline import apply_human_review, run_assessment
from cdqc_core.semantic_advisor import SemanticAdvisorConfig
from cdqc_core.utils import safe_name

st.set_page_config(page_title="C-DQC Product", page_icon="✅", layout="wide")


def _run_dir(workspace: Path, prefix: str) -> Path:
    """Unique per-run output directory.

    Previous runs are never deleted before a new run succeeds, so a failed
    re-run cannot destroy or orphan the last available assessment.
    """
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return workspace / f"{prefix}_{stamp}_{uuid4().hex[:6]}"


def _workspace() -> Path:
    if "workspace" not in st.session_state:
        st.session_state.workspace = tempfile.mkdtemp(prefix="cdqc_product_")
    path = Path(st.session_state.workspace)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _save_upload(upload, directory: Path, fallback_name: str) -> Path:
    name = Path(upload.name).name if upload and upload.name else fallback_name
    path = directory / name
    path.write_bytes(upload.getvalue())
    return path


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


st.title("C-DQC v5.0 Scientific Product")
st.caption("LLM-assisted contract construction plus three deterministic scientific agents for completeness, accuracy, and reuse readiness.")

workspace = _workspace()
assessment_tab, review_tab, about_tab = st.tabs(["1. Assess dataset", "2. Human review", "Product contract"])

with assessment_tab:
    left, right = st.columns([1, 1])
    with left:
        dataset_upload = st.file_uploader("Dataset", type=["csv", "xlsx", "xls", "parquet"], key="dataset")
        contract_upload = st.file_uploader("Approved contract JSON", type=["json"], key="contract")
        reference_upload = st.file_uploader("Clean reference dataset (optional)", type=["csv", "xlsx", "xls", "parquet"], key="reference")
        truth_upload = st.file_uploader("Corruption manifest CSV (optional)", type=["csv"], key="truth")
        strict_contract = st.checkbox("Require approved contract", value=True)
        with st.expander("LLM-assisted contract construction", expanded=True):
            llm_contract_enabled = st.checkbox("Use LLM to draft contract fields", value=True)
            llm_model = st.text_input("OpenAI model", value="gpt-5-mini")
            llm_api_key = st.text_input(
                "OpenAI API key (runtime only; alternatively set OPENAI_API_KEY)",
                value="",
                type="password",
            )
            llm_samples = st.checkbox("Send non-sensitive profile/sample values to LLM", value=True)
            st.caption("LLM proposes semantic contract fields only. Deterministic verifier blocks unsafe mappings and the LLM cannot approve the contract or compute metrics.")

    with right:
        st.subheader("Contract preparation")
        st.write("Generate a contract draft from the uploaded dataset and optional clean reference. LLM suggestions are verified before they enter the draft.")
        approver = st.text_input("Approver name", value="")
        approval_notes = st.text_input("Approval notes", value="Reviewed for governed assessment")

        if dataset_upload and st.button("Generate LLM-assisted contract draft"):
            try:
                input_dir = workspace / "input"
                input_dir.mkdir(exist_ok=True)
                dataset_path = _save_upload(dataset_upload, input_dir, "dataset.csv")
                df = read_table(dataset_path)
                reference_df = None
                if reference_upload:
                    reference_path_for_contract = _save_upload(reference_upload, input_dir, "reference_for_contract.csv")
                    reference_df = read_table(reference_path_for_contract)
                draft, advisor_report = generate_llm_assisted_contract(
                    df,
                    dataset_id=safe_name(dataset_path.stem),
                    title=dataset_path.stem,
                    reference_df=reference_df,
                    config=LLMContractAdvisorConfig(
                        enabled=llm_contract_enabled,
                        api_key=llm_api_key,
                        model=llm_model,
                        include_sample_values=llm_samples,
                        fail_on_llm_error=True,
                    ),
                )
                advisor_report_path = workspace / "contract_advisor_report.json"
                advisor_report_path.write_text(json.dumps(advisor_report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
                st.session_state.contract_advisor_report_path = str(advisor_report_path)
                st.session_state.contract_editor = json.dumps(draft.model_dump(mode="json"), indent=2, ensure_ascii=False)
                st.success("Contract draft generated and verified.")
            except Exception as exc:
                st.exception(exc)

        advisor_report_value = st.session_state.get("contract_advisor_report_path")
        if advisor_report_value and Path(advisor_report_value).exists():
            with st.expander("ContractAdvisorLLM verifier report", expanded=False):
                report = _load_json(Path(advisor_report_value))
                st.json(report)
                st.download_button(
                    "Download contract advisor report",
                    data=Path(advisor_report_value).read_bytes(),
                    file_name="contract_advisor_report.json",
                    mime="application/json",
                )

        editor_value = st.text_area(
            "Contract JSON editor",
            value=st.session_state.get("contract_editor", ""),
            height=300,
            placeholder="Generate a draft or upload an approved contract.",
        )
        if editor_value:
            st.session_state.contract_editor = editor_value

        if editor_value and st.button("Validate and approve edited contract"):
            try:
                raw = json.loads(editor_value)
                contract = DatasetContract.model_validate(raw)
                if not approver.strip():
                    raise ValueError("Approver name is required.")
                approved = approve_contract(contract, approver, approval_notes)
                approved_path = workspace / "approved_contract.json"
                save_contract(approved_path, approved)
                st.session_state.approved_contract_path = str(approved_path)
                st.session_state.contract_editor = json.dumps(approved.model_dump(mode="json"), indent=2, ensure_ascii=False)
                st.success("Contract validated and approved.")
            except Exception as exc:
                st.error(str(exc))

        approved_path_value = st.session_state.get("approved_contract_path")
        if approved_path_value and Path(approved_path_value).exists():
            st.download_button(
                "Download approved contract",
                data=Path(approved_path_value).read_bytes(),
                file_name="approved_contract.json",
                mime="application/json",
            )

    st.divider()
    run_disabled = dataset_upload is None
    if st.button("Run governed assessment", type="primary", disabled=run_disabled):
        try:
            input_dir = workspace / "input"
            input_dir.mkdir(exist_ok=True)
            dataset_path = _save_upload(dataset_upload, input_dir, "dataset.csv")

            if contract_upload:
                contract_path = _save_upload(contract_upload, input_dir, "contract.json")
                contract_source = "uploaded"
            elif st.session_state.get("approved_contract_path") and Path(st.session_state.approved_contract_path).exists():
                contract_path = Path(st.session_state.approved_contract_path)
                contract_source = "session"
            else:
                contract_path = None
                contract_source = "none"

            # A contract approved earlier in this session is reused only after an
            # explicit dataset match check. Silent reuse against a different
            # dataset previously executed the assessment under the wrong contract.
            if contract_path is not None and contract_source == "session":
                previous = json.loads(contract_path.read_text(encoding="utf-8"))
                declared = set(map(str, previous.get("columns", {})))
                observed = set(map(str, read_table(dataset_path).columns))
                if declared != observed:
                    missing = sorted(observed - declared)
                    extra = sorted(declared - observed)
                    raise ValueError(
                        "The contract approved earlier in this session was built for a different dataset "
                        f"(columns missing from contract: {missing}; contract columns absent from dataset: {extra}). "
                        "Generate and approve a new contract for this dataset, or upload the matching approved contract JSON."
                    )
                st.info("Reusing the contract approved earlier in this session (dataset columns match).")

            reference_path = _save_upload(reference_upload, input_dir, "reference.csv") if reference_upload else None
            truth_path = _save_upload(truth_upload, input_dir, "truth.csv") if truth_upload else None
            output_dir = _run_dir(workspace, "assessment")

            with st.spinner("Running C-DQC agents and verifier..."):
                result = run_assessment(
                    dataset_path,
                    output_dir,
                    config_path=contract_path,
                    reference_path=reference_path,
                    truth_manifest_path=truth_path,
                    require_approved_contract=strict_contract,
                    create_zip=True,
                    semantic_config=SemanticAdvisorConfig(enabled=False),
                )
            # Session pointers are updated only after a fully successful run,
            # so a failed re-run leaves the previous assessment intact and viewable.
            st.session_state.assessment_result = result
            st.session_state.input_path = str(dataset_path)
            st.session_state.assessment_dir = result["output_dir"]
            st.session_state.reference_path = str(reference_path) if reference_path else None
            st.session_state.truth_path = str(truth_path) if truth_path else None
            contract_warnings = (result.get("manifest") or {}).get("contract_warnings") or []
            for warning in contract_warnings:
                st.warning(warning)
            st.success("Assessment completed.")
        except Exception as exc:
            st.exception(exc)

    result = st.session_state.get("assessment_result")
    if result and not Path(result["output_dir"]).exists():
        st.warning(
            "The previous assessment output directory no longer exists (the app session or workspace was reset). "
            "Run the assessment again."
        )
        result = None
        st.session_state.pop("assessment_result", None)
        st.session_state.pop("assessment_dir", None)
    if result:
        metrics = result["quality_support_metrics"]
        cols = st.columns(6)
        cols[0].metric("Verdict", metrics.get("verdict", "n/a"))
        cols[1].metric("Evidence mode", metrics.get("evidence_mode", "n/a"))
        cols[2].metric("DQI", f"{metrics.get('quality_support_index', 0):.3f}")
        cols[3].metric("Completeness", f"{metrics.get('completeness_support', 0):.3f}")
        accuracy_label = "Validated accuracy" if metrics.get("A_validated") is not None else "Contract validity support"
        cols[4].metric(accuracy_label, f"{metrics.get('accuracy_support', 0):.3f}")
        cols[5].metric("Reuse readiness", f"{metrics.get('reuse_readiness_support', 0):.3f}")

        out = Path(result["output_dir"])
        summary_tab, issues_tab, agents_tab, files_tab = st.tabs(["Summary", "Issues", "Agents", "Outputs"])
        with summary_tab:
            st.json(metrics)
        with issues_tab:
            issues = pd.read_csv(out / "issues.csv")
            st.dataframe(issues, use_container_width=True, height=500)
        with agents_tab:
            for label, prefix in (
                ("CompletenessAgent", "completeness"),
                ("AccuracyAgent", "accuracy"),
                ("ReuseAgent", "reuse"),
            ):
                with st.expander(label, expanded=True):
                    st.json(_load_json(out / f"{prefix}_agent_result.json"))
            with st.expander("Execution and governance trace"):
                st.json(_load_json(out / "agent_trace.json"))
        with files_tab:
            st.write(sorted(path.name for path in out.iterdir()))
            archive = Path(result["archive_path"])
            st.download_button(
                "Download complete assessment bundle",
                data=archive.read_bytes(),
                file_name=archive.name,
                mime="application/zip",
            )
            st.download_button(
                "Download HTML report",
                data=(out / "report.html").read_bytes(),
                file_name="cdqc_report.html",
                mime="text/html",
            )

with review_tab:
    assessment_dir_value = st.session_state.get("assessment_dir")
    input_path_value = st.session_state.get("input_path")
    if not assessment_dir_value or not input_path_value:
        st.info("Run an assessment first.")
    else:
        assessment_dir = Path(assessment_dir_value)
        queue = pd.read_csv(assessment_dir / "review_queue.csv", keep_default_na=False)
        st.write("Review grouped findings first, then inspect or override individual proposals when necessary.")
        reviewer_default = st.text_input("Default reviewer for approved items", key="reviewer_default")
        group_columns = ["issue_type", "column", "action", "risk", "executable"]
        queue["group_id"] = queue[group_columns].astype(str).agg("|".join, axis=1)
        grouped = (
            queue.groupby(["group_id", *group_columns], dropna=False)
            .size()
            .reset_index(name="affected_count")
        )
        grouped["decision"] = "pending"
        grouped["reviewer"] = ""
        grouped["reviewer_comment"] = ""
        grouped_edited = st.data_editor(
            grouped,
            use_container_width=True,
            height=340,
            disabled=["group_id", *group_columns, "affected_count"],
            column_config={
                "decision": st.column_config.SelectboxColumn(
                    "group decision",
                    options=["pending", "approve", "reject", "defer"],
                    required=True,
                )
            },
            key="group_review_editor",
        )

        with st.expander("Cell and row level preview / overrides"):
            editable_columns = [
                "proposal_id", "group_id", "issue_type", "scope", "row_index", "column", "current_value",
                "proposed_value", "action", "risk", "executable", "rationale", "decision", "reviewer", "reviewer_comment"
            ]
            display_queue = queue[[column for column in editable_columns if column in queue.columns]].copy()
            edited = st.data_editor(
                display_queue,
                use_container_width=True,
                height=520,
                disabled=[
                    "proposal_id", "group_id", "issue_type", "scope", "row_index", "column", "current_value",
                    "proposed_value", "action", "risk", "executable", "rationale"
                ],
                column_config={
                    "decision": st.column_config.SelectboxColumn(
                        "decision override",
                        options=["pending", "approve", "reject", "defer"],
                        required=True,
                    )
                },
                key="review_editor",
            )

        allow_medium = st.checkbox("Allow approved medium-risk actions", value=False)
        if st.button("Apply approved changes to a curated copy", type="primary"):
            try:
                review_path = workspace / "review_decisions.csv"
                full_queue = queue.copy()
                group_decisions = grouped_edited.set_index("group_id")[["decision", "reviewer", "reviewer_comment"]]
                for row_index, row in full_queue.iterrows():
                    group_review = group_decisions.loc[row["group_id"]]
                    if str(group_review["decision"]) != "pending":
                        full_queue.at[row_index, "decision"] = group_review["decision"]
                        full_queue.at[row_index, "reviewer"] = group_review["reviewer"]
                        full_queue.at[row_index, "reviewer_comment"] = group_review["reviewer_comment"]
                individual = edited.set_index("proposal_id")
                for row_index, row in full_queue.iterrows():
                    override = individual.loc[row["proposal_id"]]
                    if str(override["decision"]) != "pending":
                        full_queue.at[row_index, "decision"] = override["decision"]
                        full_queue.at[row_index, "reviewer"] = override["reviewer"]
                        full_queue.at[row_index, "reviewer_comment"] = override["reviewer_comment"]
                if reviewer_default:
                    mask = full_queue["decision"].eq("approve") & full_queue["reviewer"].astype(str).str.strip().eq("")
                    full_queue.loc[mask, "reviewer"] = reviewer_default
                full_queue.drop(columns=["group_id"], errors="ignore").to_csv(review_path, index=False)
                review_output = _run_dir(workspace, "review_output")
                with st.spinner("Applying approved changes and re-assessing the curated copy..."):
                    review_result = apply_human_review(
                        Path(input_path_value),
                        assessment_dir,
                        review_path,
                        review_output,
                        allow_medium_risk=allow_medium,
                        reference_path=Path(st.session_state.reference_path) if st.session_state.get("reference_path") else None,
                        truth_manifest_path=Path(st.session_state.truth_path) if st.session_state.get("truth_path") else None,
                        create_zip=True,
                    )
                st.session_state.review_result = review_result
                st.success("Curated output created. The source dataset was not modified.")
            except Exception as exc:
                st.exception(exc)

        review_result = st.session_state.get("review_result")
        if review_result:
            comparison = review_result["comparison"]
            st.subheader("Before and after")
            st.json(comparison["delta"])
            archive = Path(review_result["archive_path"])
            st.download_button(
                "Download curated output bundle",
                data=archive.read_bytes(),
                file_name=archive.name,
                mime="application/zip",
            )

with about_tab:
    st.markdown(
        """
### Product rules

- The source dataset is immutable and hash-verified.
- Completeness, accuracy, and reuse are handled by separate specialist agents.
- Confirmed, supported, and candidate findings are kept distinct.
- Candidate findings cannot authorize a data change.
- No imputation is executed automatically.
- Curated output is a separate copy and requires named human approval.
- Precision, recall, and F1 are reported only with a corruption manifest.
- Exact cell accuracy is reported only with a clean reference dataset.
- Deterministic metrics do not require an API. The optional OpenAI SemanticAdvisor is advisory only and cannot modify data, findings, metrics, or verdicts.
        """
    )
