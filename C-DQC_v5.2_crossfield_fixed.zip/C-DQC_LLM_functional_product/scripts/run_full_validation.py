from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "validation_results"
RESULTS.mkdir(parents=True, exist_ok=True)


def run(command: list[str], *, timeout: int = 600) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=timeout)
    print(result.stdout)
    if result.returncode:
        print(result.stderr)
        raise SystemExit(result.returncode)
    return result


pytest_result = run([sys.executable, "-m", "pytest", "-q"])
benchmark_dir = RESULTS / "benchmark"
if benchmark_dir.exists():
    shutil.rmtree(benchmark_dir)
run(
    [
        sys.executable,
        "-m",
        "cdqc_core",
        "benchmark",
        "--output",
        str(benchmark_dir),
        "--runs",
        "30",
        "--rows",
        "200",
    ],
    timeout=900,
)

from cdqc_core.contract import approve_contract, load_contract, save_contract
from cdqc_core.io import read_table
benchmark_input = benchmark_dir / "example_corrupted_input.csv"
benchmark_df = read_table(benchmark_input)
benchmark_contract, _ = load_contract(
    benchmark_dir / "example_dataset_config.json",
    dataset_columns=[str(column) for column in benchmark_df.columns],
    dataset_id_fallback="synthetic_health_tabular",
)
benchmark_contract = approve_contract(
    benchmark_contract,
    "C-DQC validation runner",
    "Approved for controlled product validation.",
)
save_contract(benchmark_dir / "example_approved_contract.json", benchmark_contract)

example_output = RESULTS / "example_assessment"
if example_output.exists():
    shutil.rmtree(example_output)
product_result = run(
    [
        sys.executable,
        "-m",
        "cdqc_core",
        "assess",
        "--input",
        str(benchmark_dir / "example_corrupted_input.csv"),
        "--contract",
        str(benchmark_dir / "example_approved_contract.json"),
        "--reference",
        str(benchmark_dir / "example_clean_reference.csv"),
        "--truth-manifest",
        str(benchmark_dir / "example_corruption_manifest.csv"),
        "--require-approved-contract",
        "--output",
        str(example_output),
        "--no-zip",
    ]
)

required_outputs = {
    "completeness_agent_result.json",
    "completeness_metrics.json",
    "completeness_recommendations.json",
    "accuracy_agent_result.json",
    "accuracy_metrics.json",
    "accuracy_recommendations.json",
    "reuse_agent_result.json",
    "reuse_metrics.json",
    "reuse_recommendations.json",
    "aggregate_metrics.json",
    "metric_availability.json",
    "agent_validation_metrics.json",
    "reference_exact_metrics.json",
    "detection_benchmark_metrics.json",
    "agent_trace.json",
    "run_manifest.json",
    "report.html",
}
observed = {path.name for path in example_output.iterdir() if path.is_file()}
missing = sorted(required_outputs - observed)
if missing:
    raise SystemExit(f"Missing scientific outputs: {missing}")

metrics = json.loads((example_output / "aggregate_metrics.json").read_text(encoding="utf-8"))
manifest_metrics = json.loads((example_output / "detection_benchmark_metrics.json").read_text(encoding="utf-8"))
reference_metrics = json.loads((example_output / "reference_exact_metrics.json").read_text(encoding="utf-8"))
trace = json.loads((example_output / "agent_trace.json").read_text(encoding="utf-8"))
benchmark_report = json.loads((benchmark_dir / "benchmark_report.json").read_text(encoding="utf-8"))

report = {
    "release": "C-DQC v5.0 Scientific Product",
    "automated_tests": pytest_result.stdout.strip(),
    "benchmark_completed": True,
    "benchmark_design": benchmark_report["benchmark_design"],
    "example_assessment_completed": True,
    "scientific_agents": [
        event["agent"]
        for event in trace
        if event["agent"] in {"CompletenessAgent", "AccuracyAgent", "ReuseAgent"}
    ],
    "evidence_mode": metrics["evidence_mode"],
    "DQI_support": metrics["DQI_support"],
    "DQI_validated": metrics["DQI_validated"],
    "reference_tolerance_adjusted_accuracy": reference_metrics["tolerance_adjusted_accuracy"],
    "manifest_precision": manifest_metrics["precision"],
    "manifest_recall": manifest_metrics["recall"],
    "manifest_f1": manifest_metrics["f1"],
    "manifest_MCC": manifest_metrics["MCC"],
    "verifier_passed": trace[-1]["output_summary"]["passed"],
    "required_outputs_present": not missing,
    "missing_outputs": missing,
    "openai_live_call_executed": False,
    "openai_validation": "Payload redaction and fail-safe integration are covered by automated tests. A live call requires a user-supplied API key.",
}
(ROOT / "VALIDATION_REPORT.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
