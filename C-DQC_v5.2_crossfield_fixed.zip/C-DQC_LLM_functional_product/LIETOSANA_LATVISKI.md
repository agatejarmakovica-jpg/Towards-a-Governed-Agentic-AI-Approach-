# C-DQC v5.0 lietošana

## Google Colab

1. Atver tukšu Google Colab notebook.
2. Augšupielādē `C-DQC_v5.0_COLAB_LAUNCH.py`.
3. Palaid:

```python
%run C-DQC_v5.0_COLAB_LAUNCH.py
```

4. Kad tiek prasīts, augšupielādē `C-DQC_v5.0_scientific_product.zip`.
5. Atver izdrukāto `trycloudflare.com` saiti.

Šis ir viens fiksēts palaišanas veids. Projekta ZIP nav jāizpako manuāli.

## Novērtējums

1. Laukā `Dataset` ievieto datu kopu.
2. Ievieto apstiprinātu līgumu vai ģenerē melnrakstu.
3. Aizpildi metadatus, noteikumus, atļautās kategorijas, primāro atslēgu un references rindu savietošanas politiku.
4. Apstiprini līgumu ar vārdu.
5. Ja pieejams, ievieto tīro references datu kopu.
6. Ja veikta kontrolēta kļūdu injicēšana, ievieto corruption manifest CSV.
7. Spied `Run governed assessment`.

## Rezultātu interpretācija

- `CONTRACT_ONLY` nedod faktiskās precizitātes pierādījumu.
- `CLEAN_REFERENCE` dod šūnu precizitātes metriku.
- `CORRUPTION_MANIFEST` dod detekcijas precision, recall, F1 un MCC.
- `REFERENCE_AND_MANIFEST` nodrošina abus pierādījumu veidus.
- kandidāti nav apstiprinātas kļūdas;
- augsts DQI neatceļ bloķējošus privātuma vai līguma nosacījumus.

## Human-in-the-Loop

Vispirms pieņem grupētu lēmumu problēmas tipa un kolonnas līmenī. Vajadzības gadījumā atver šūnu un rindu priekšskatījumu un veic individuālus izņēmumus. Apstiprinātām izmaiņām jānorāda pārskatītājs. C-DQC izveido jaunu curated failu un nemaina avota datu kopu.

## OpenAI SemanticAdvisor

OpenAI pieslēgšana nav obligāta. API atslēgu ievada tikai izpildes laikā vai glabā `OPENAI_API_KEY`. Advisor saņem metadatus un kopsavilkumus, bet nevar mainīt datus, metriku vai spriedumu.
