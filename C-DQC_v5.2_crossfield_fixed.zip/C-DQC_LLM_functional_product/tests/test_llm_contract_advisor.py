from __future__ import annotations

import pandas as pd

from cdqc_core.llm_contract_advisor import LLMContractAdvisorConfig, generate_llm_assisted_contract


def test_reference_assisted_contract_does_not_map_valid_blood_types() -> None:
    messy = pd.DataFrame({"Blood Type": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "AB -"]})
    clean = pd.DataFrame({"Blood Type": ["A-", "A+", "B-", "B+", "AB-", "AB+", "O-", "O+", "AB-"]})
    contract, report = generate_llm_assisted_contract(
        messy,
        dataset_id="blood_test",
        title="blood_test",
        reference_df=clean,
        config=LLMContractAdvisorConfig(enabled=False),
    )
    meta = contract.columns["Blood Type"]
    assert set(meta.approved_allowed_values) == {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"}
    assert meta.canonical_mapping == {"AB -": "AB-"} or meta.canonical_mapping == {}
    assert all(
        not (item["raw"] in {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"})
        for item in report["blocked_mappings"]
    )


def test_same_dataset_reference_is_blocked(tmp_path) -> None:
    from cdqc_core.pipeline import run_assessment
    from cdqc_core.contract import approve_contract, save_contract

    df = pd.DataFrame({"x": [1, 2, 3]})
    path = tmp_path / "data.csv"
    df.to_csv(path, index=False)
    contract, _ = generate_llm_assisted_contract(df, dataset_id="data", title="data", config=LLMContractAdvisorConfig(enabled=False))
    approved = approve_contract(contract, "tester")
    contract_path = tmp_path / "contract.json"
    save_contract(contract_path, approved)
    try:
        run_assessment(path, tmp_path / "out", config_path=contract_path, reference_path=path, require_approved_contract=True)
    except ValueError as exc:
        assert "byte-identical" in str(exc)
    else:
        raise AssertionError("Identical dataset/reference was not blocked")


# ---------------------------------------------------------------------------
# Strict structured-output wire schema and fallback normalizer regressions.
# ---------------------------------------------------------------------------

def test_wire_schema_is_strict_compliant() -> None:
    """Guards against reintroducing dict fields or default-driven required drift.

    The original production failure was a 400 invalid_json_schema caused by a
    dict[str, str] field producing additionalProperties in the strict schema.
    """
    from openai.lib._pydantic import to_strict_json_schema
    from cdqc_core.llm_contract_advisor import WireAdvisorOutput

    schema = to_strict_json_schema(WireAdvisorOutput)

    def walk(node):
        if isinstance(node, dict):
            if node.get("type") == "object":
                assert set(node.get("properties", {})) == set(node.get("required", []))
                assert node.get("additionalProperties") is False
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    walk(schema)


def test_wire_to_internal_conversion() -> None:
    from cdqc_core.llm_contract_advisor import (
        WireAdvisorOutput, WireColumnSuggestion, WireCrossFieldRule,
        WireDatasetSuggestion, WireMappingEntry, WireUnresolvedQuestion, _wire_to_internal,
    )

    wire = WireAdvisorOutput(
        summary="s",
        dataset=WireDatasetSuggestion(
            description="d", intended_reuse=None, privacy_status=None,
            license=None, provenance=None, confidence=1.7, questions_for_user=[],
        ),
        columns=[WireColumnSuggestion(
            column="Blood Type", role="categorical", description=None, measurement_unit=None,
            sensitivity=None, approved_allowed_values=["A+", "A-"],
            canonical_mapping=[WireMappingEntry(raw_value=" AB - ", canonical_value="AB-"),
                               WireMappingEntry(raw_value="", canonical_value="X")],
            target_format=None, source_formats=[], regex=None, standard_or_code_system=None,
            required=None, confidence=-0.3, rationale=None, warnings=[],
        )],
        cross_field_rules=[WireCrossFieldRule(
            rule_id="r1", description="admission before discharge", left_column="Date of Admission",
            operator="<=", right_column="Discharge Date", right_value=None,
            severity="candidate", confidence=0.5,
        )],
        unsafe_mapping_warnings=[],
        unresolved_questions=[
            WireUnresolvedQuestion(column="Name", question="Keep for internal use?"),
            WireUnresolvedQuestion(column=None, question="Dataset license?"),
        ],
    )
    internal = _wire_to_internal(wire)
    assert internal.columns[0].canonical_mapping == {"AB -": "AB-"}
    assert internal.columns[0].confidence == 0.0
    assert internal.dataset.confidence == 1.0
    assert internal.cross_field_rules[0].operator == "<="
    assert internal.unresolved_questions == [
        "Column 'Name': Keep for internal use?",
        "Dataset license?",
    ]


def test_normalizer_coerces_observed_llm_drift() -> None:
    """Reproduces the exact production drift: operation flags and nested example
    dicts inside canonical_mapping, cross-field rules without required keys,
    severity 'error', and dict-shaped unresolved questions. All 34 validation
    errors of that class must now be either coerced or dropped with audit."""
    from cdqc_core.llm_contract_advisor import LLMContractAdvisorOutput, _normalize_llm_payload

    raw = {
        "summary": "x",
        "columns": [
            {"column": "Name", "canonical_mapping": {"trim_whitespace": True, "normalize_spaces": True}},
            {"column": "Blood Type", "canonical_mapping": {
                "trim_spaces_and_upper": True,
                "normalize_examples": {"A +": "A+", "A -": "A-", "ab+": "AB+", "ab-": "AB-"},
            }},
            {"column": "Insurance", "canonical_mapping": [
                {"raw": "BCBS", "canonical": "Blue Cross"},
                {"source_value": "unitedhealthcare", "canonical_value": "UnitedHealthcare"},
                {"bogus": 1},
            ]},
        ],
        "cross_field_rules": [
            {"rule": "discharge_after_admission", "severity": "error"},
            {"rule_id": "r_ok", "description": "d", "left_column": "Date of Admission",
             "operator": "<=", "right_column": "Discharge Date", "severity": "confirmed", "confidence": 0.9},
        ],
        "unresolved_questions": [
            {"column": "Name", "question": "Required for internal use?"},
            {"column": "General", "question": "Downstream uses?"},
            "Plain string question",
        ],
    }
    data = _normalize_llm_payload(raw)
    dropped = data.pop("_normalizer_dropped")
    parsed = LLMContractAdvisorOutput.model_validate(data)

    assert parsed.columns[0].canonical_mapping == {}
    assert parsed.columns[1].canonical_mapping == {"A +": "A+", "A -": "A-", "ab+": "AB+", "ab-": "AB-"}
    assert parsed.columns[2].canonical_mapping == {"BCBS": "Blue Cross", "unitedhealthcare": "UnitedHealthcare"}
    # Rule without left_column/operator is dropped, not guessed.
    assert [rule.rule_id for rule in parsed.cross_field_rules] == ["r_ok"]
    # LLM cannot self-confirm rules.
    assert parsed.cross_field_rules[0].severity == "supported"
    assert parsed.unresolved_questions == [
        "Column 'Name': Required for internal use?",
        "Downstream uses?",
        "Plain string question",
    ]
    # Every dropped item is auditable.
    assert any(item.get("field") == "canonical_mapping" for item in dropped)
    assert any("left_column" in str(item.get("reason", "")) for item in dropped)


def test_call_advisor_uses_strict_parse(monkeypatch) -> None:
    from cdqc_core import llm_contract_advisor as mod

    wire = mod.WireAdvisorOutput(
        summary="ok",
        dataset=mod.WireDatasetSuggestion(
            description=None, intended_reuse=None, privacy_status=None,
            license=None, provenance=None, confidence=0.0, questions_for_user=[],
        ),
        columns=[], cross_field_rules=[], unsafe_mapping_warnings=[], unresolved_questions=[],
    )

    class FakeResponse:
        id = "resp_1"
        usage = None
        output_parsed = wire

    class FakeResponses:
        def parse(self, **kwargs):
            assert kwargs["text_format"] is mod.WireAdvisorOutput
            assert kwargs["store"] is False
            return FakeResponse()

        def create(self, **kwargs):
            raise AssertionError("Strict parse path must not fall back in this test.")

    class FakeOpenAI:
        def __init__(self, api_key):
            self.responses = FakeResponses()

    import openai
    monkeypatch.setattr(openai, "OpenAI", FakeOpenAI)
    config = mod.LLMContractAdvisorConfig(enabled=True, api_key="test-key")
    output, audit = mod._call_openai_contract_advisor({"reference_supplied": False}, config)
    assert output is not None and output.summary == "ok"
    assert audit["api_mode"] == "responses_parse_strict"
    assert audit["structured_output_enforced"] is True
    assert audit["fallback_errors"] == []


def test_call_advisor_falls_back_to_json_object(monkeypatch) -> None:
    import json as _json
    from cdqc_core import llm_contract_advisor as mod

    class FakeResponse:
        id = "resp_2"
        usage = None
        output_text = _json.dumps({
            "summary": "fallback",
            "columns": [{"column": "c", "canonical_mapping": {"trim_whitespace": True}}],
            "cross_field_rules": [],
            "unresolved_questions": [{"column": "c", "question": "q"}],
        })

    class FakeResponses:
        def parse(self, **kwargs):
            raise TypeError("no text_format support in this fake SDK")

        def create(self, **kwargs):
            assert kwargs.get("text", {}).get("format", {}).get("type") == "json_object"
            return FakeResponse()

    class FakeOpenAI:
        def __init__(self, api_key):
            self.responses = FakeResponses()

    import openai
    monkeypatch.setattr(openai, "OpenAI", FakeOpenAI)
    config = mod.LLMContractAdvisorConfig(enabled=True, api_key="test-key")
    output, audit = mod._call_openai_contract_advisor({"reference_supplied": False}, config)
    assert output.summary == "fallback"
    assert output.columns[0].canonical_mapping == {}
    assert output.unresolved_questions == ["Column 'c': q"]
    assert audit["api_mode"] == "responses_json_object"
    assert audit["structured_output_enforced"] is False
    assert audit["fallback_errors"][0]["stage"] == "responses_parse_strict"
    assert audit["normalizer_dropped"]
