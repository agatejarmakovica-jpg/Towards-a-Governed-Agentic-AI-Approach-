from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from cdqc_core.agents import run_agentic_assessment
from cdqc_core.contract import (
    Approval,
    ColumnContract,
    CrossFieldRule,
    DatasetContract,
    DatasetMetadata,
    approve_contract,
    generate_draft_contract,
    save_contract,
)
from cdqc_core.pipeline import run_assessment
from cdqc_core.semantic_advisor import build_advisor_payload


def approved_contract(columns: dict[str, ColumnContract], *, primary_key: list[str] | None = None) -> DatasetContract:
    return DatasetContract(
        dataset_id="generic_test",
        approval=Approval(
            status="approved",
            approved_by="Tester",
            approved_at_utc="2026-07-05T00:00:00+00:00",
        ),
        dataset_metadata=DatasetMetadata(
            title="Generic test",
            description="Generic tabular validation dataset",
            provenance="Unit test",
            version="1.0",
            license="Test",
            intended_reuse="Scientific validation",
            privacy_status="Synthetic",
        ),
        columns=columns,
        primary_key=primary_key or [],
    )


def test_draft_does_not_approve_dirty_observed_categories():
    df = pd.DataFrame({"AnyCategory": ["valid", "invalid", "valid"]})
    draft = generate_draft_contract(df, "generic")
    meta = draft.columns["AnyCategory"]
    assert "invalid" in meta.observed_values_sample
    assert meta.approved_allowed_values == []
    assert meta.allowed_values == []


def test_contract_role_drives_numeric_validation_for_arbitrary_column_name():
    df = pd.DataFrame({"X17": ["10", "ten", "999"]})
    contract = approved_contract(
        {
            "X17": ColumnContract(
                role="numeric",
                description="Generic numeric variable",
                canonical_mapping={"ten": "10"},
                valid_range=(0, 100),
            )
        }
    )
    result = run_agentic_assessment(df, contract)
    accuracy = result["agent_results"]["AccuracyAgent"]
    types = {(issue.issue_type, issue.row_index) for issue in accuracy.issues}
    assert ("numeric_parse_failure", 1) not in types
    assert ("range_violation", 2) in types


def test_approved_category_has_priority_over_generic_missing_heuristic():
    df = pd.DataFrame({"C": ["NONE", "A"]})
    contract = approved_contract(
        {
            "C": ColumnContract(
                role="categorical",
                description="Generic category",
                approved_allowed_values=["NONE", "A"],
            )
        }
    )
    result = run_agentic_assessment(df, contract)
    completeness = result["agent_results"]["CompletenessAgent"]
    assert not any(issue.value == "NONE" for issue in completeness.issues)


def test_reference_is_used_inside_accuracy_agent_with_key_alignment():
    df = pd.DataFrame({"K": ["b", "a"], "M": [8.0, 1.0], "C": ["x", "y"]})
    reference = pd.DataFrame({"K": ["a", "b"], "M": [1.0, 2.0], "C": ["y", "x"]})
    contract = approved_contract(
        {
            "K": ColumnContract(role="text", description="Key", uniqueness_required=True),
            "M": ColumnContract(role="numeric", description="Measurement", numeric_tolerance=0.0),
            "C": ColumnContract(role="categorical", description="Category"),
        },
        primary_key=["K"],
    )
    result = run_agentic_assessment(df, contract, reference_df=reference)
    accuracy = result["agent_results"]["AccuracyAgent"]
    metrics = accuracy.metrics["reference_metrics"]
    assert metrics["alignment_method"] == "primary_key"
    assert metrics["mismatched_cells"] == 1
    assert metrics["tolerance_adjusted_accuracy"] == 0.75
    assert accuracy.execution_details["clean_reference_used_by_accuracy_agent"] is True
    assert result["quality_support_metrics"]["evidence_mode"] == "CLEAN_REFERENCE"
    assert result["quality_support_metrics"]["A_validated"] == 0.75


def test_contract_only_mode_does_not_claim_validated_accuracy():
    df = pd.DataFrame({"A": [1, 2, 3]})
    contract = approved_contract({"A": ColumnContract(role="numeric", description="A")})
    result = run_agentic_assessment(df, contract)
    metrics = result["quality_support_metrics"]
    assert metrics["evidence_mode"] == "CONTRACT_ONLY"
    assert metrics["A_validated"] is None
    assert metrics["DQI_validated"] is None
    availability = metrics["metric_availability"]
    exact = next(item for item in availability if item["metric"] == "exact_cell_accuracy")
    assert exact["state"] == "NOT_COMPUTABLE"


def test_machine_readability_is_computed_not_constant():
    good = pd.DataFrame({"A": [1, 2], "B": ["x", "y"]})
    bad = pd.DataFrame({"Unnamed: 0": [1, 2], "B": ["x", 2]})
    good_contract = approved_contract(
        {
            "A": ColumnContract(role="numeric", description="A"),
            "B": ColumnContract(role="text", description="B"),
        }
    )
    bad_contract = approved_contract(
        {
            "Unnamed: 0": ColumnContract(role="numeric", description="Index-like"),
            "B": ColumnContract(role="text", description="Mixed"),
        }
    )
    good_score = run_agentic_assessment(good, good_contract)["agent_results"]["ReuseAgent"].metrics["machine_readability"]
    bad_score = run_agentic_assessment(bad, bad_contract)["agent_results"]["ReuseAgent"].metrics["machine_readability"]
    assert good_score > bad_score
    assert bad_score < 1.0


def test_cross_field_rule_is_generic_and_contract_driven():
    df = pd.DataFrame({"Start": [1, 5], "End": [2, 4]})
    contract = approved_contract(
        {
            "Start": ColumnContract(role="numeric", description="Start"),
            "End": ColumnContract(role="numeric", description="End"),
        }
    )
    contract.cross_field_rules = [
        CrossFieldRule(
            rule_id="R1",
            description="End must not precede start",
            left_column="End",
            operator=">=",
            right_column="Start",
        )
    ]
    result = run_agentic_assessment(df, contract)
    accuracy = result["agent_results"]["AccuracyAgent"]
    violations = [issue for issue in accuracy.issues if issue.issue_type == "cross_field_rule_violation"]
    assert [issue.row_index for issue in violations] == [1]


def test_pipeline_writes_three_agent_scientific_outputs(tmp_path: Path):
    df = pd.DataFrame({"A": [1, 2, 3]})
    input_path = tmp_path / "input.csv"
    contract_path = tmp_path / "contract.json"
    output = tmp_path / "out"
    df.to_csv(input_path, index=False)
    contract = approved_contract({"A": ColumnContract(role="numeric", description="A")})
    save_contract(contract_path, contract)
    run_assessment(
        input_path,
        output,
        config_path=contract_path,
        require_approved_contract=True,
        create_zip=False,
    )
    required = {
        "completeness_agent_result.json",
        "completeness_metrics.json",
        "completeness_recommendations.json",
        "accuracy_agent_result.json",
        "accuracy_metrics.json",
        "accuracy_recommendations.json",
        "reuse_agent_result.json",
        "reuse_metrics.json",
        "reuse_recommendations.json",
        "aggregate_metrics.json",
        "metric_availability.json",
        "agent_validation_metrics.json",
    }
    assert required <= {path.name for path in output.iterdir()}
    trace = json.loads((output / "agent_trace.json").read_text())
    scientific = [row["agent"] for row in trace if row["agent"].endswith("Agent")]
    assert scientific == ["CompletenessAgent", "AccuracyAgent", "ReuseAgent"]


def test_semantic_advisor_payload_redacts_sensitive_values():
    df = pd.DataFrame({"Identifier": ["Alice", "Bob"], "Feature": ["A", "B"]})
    contract = approved_contract(
        {
            "Identifier": ColumnContract(
                role="text",
                description="Direct identifier",
                sensitivity="direct_identifier",
            ),
            "Feature": ColumnContract(role="categorical", description="Feature"),
        }
    )
    result = run_agentic_assessment(df, contract)
    payload = build_advisor_payload(
        df,
        contract,
        list(result["agent_results"].values()),
        result["quality_support_metrics"],
        include_non_sensitive_sample_values=True,
    )
    serialized = json.dumps(payload)
    assert "Alice" not in serialized
    feature = next(item for item in payload["dataset"]["columns"] if item["name"] == "Feature")
    assert feature["sample_values"] == ["A", "B"]


def test_manifest_metrics_exclude_reference_comparison_findings():
    df = pd.DataFrame({"K": ["a"], "V": [None]})
    reference = pd.DataFrame({"K": ["a"], "V": [1.0]})
    manifest = pd.DataFrame(
        [
            {
                "issue_type": "explicit_missingness",
                "scope": "cell",
                "row_index": 0,
                "column": "V",
                "original_value": 1.0,
                "corrupted_value": None,
            }
        ]
    )
    contract = approved_contract(
        {
            "K": ColumnContract(role="text", description="Key", uniqueness_required=True),
            "V": ColumnContract(role="numeric", description="Value"),
        },
        primary_key=["K"],
    )
    result = run_agentic_assessment(
        df,
        contract,
        reference_df=reference,
        truth_manifest=manifest,
    )
    metrics = result["quality_support_metrics"]["manifest_detection_metrics"]
    assert metrics["true_positives"] == 1
    assert metrics["false_positives"] == 0
    assert metrics["precision"] == 1.0
    assert any(
        issue.issue_type == "reference_cell_mismatch"
        for issue in result["agent_results"]["AccuracyAgent"].issues
    )


def test_phone_reference_comparison_is_role_normalized():
    df = pd.DataFrame({"K": ["a"], "Contact": ["+371 1234 5678"]})
    reference = pd.DataFrame({"K": ["a"], "Contact": [37112345678]})
    contract = approved_contract(
        {
            "K": ColumnContract(role="text", description="Key", uniqueness_required=True),
            "Contact": ColumnContract(role="phone", description="Phone"),
        },
        primary_key=["K"],
    )
    result = run_agentic_assessment(df, contract, reference_df=reference)
    reference_metrics = result["agent_results"]["AccuracyAgent"].metrics["reference_metrics"]
    assert reference_metrics["tolerance_adjusted_accuracy"] == 1.0
    assert reference_metrics["per_column_accuracy"]["Contact"]["wrong"] == 0


def test_cross_field_rules_use_typed_comparison() -> None:
    """Regression for two production defects on real data:
    (1) lexicographic string comparison ('25' <= '120' -> False) flagged every
    valid Age row; (2) mixed dtypes (float 31.0 >= '0') raised TypeError and
    the exception path counted as a violation. Both classes must yield zero
    false positives, uncoercible values go to not_evaluable, and only
    confirmed-severity rules feed confirmed contract cells."""
    import pandas as pd
    from cdqc_core.accuracy_agent import AccuracyAgent
    from cdqc_core.contract import CrossFieldRule, generate_draft_contract

    df = pd.DataFrame({
        "Age": [25.0, 60.0, 135.0, None, float("nan")],
        "Admit": ["2020-01-10", "2020-05-01", "2020-06-01", "2020-07-01", "not a date"],
        "Discharge": ["2020-01-15", "2020-04-01", "2020-06-30", "2020-07-05", "2020-08-01"],
    })
    contract = generate_draft_contract(df, dataset_id="t", title="t")
    contract.columns["Age"].role = "numeric"
    contract.columns["Admit"].role = "date"
    contract.columns["Discharge"].role = "date"
    contract.cross_field_rules = [
        CrossFieldRule(rule_id="max", description="d", severity="candidate",
                       left_column="Age", operator="<=", right_value="130"),
        CrossFieldRule(rule_id="min", description="d", severity="candidate",
                       left_column="Age", operator=">=", right_value="0"),
        CrossFieldRule(rule_id="order", description="d", severity="confirmed",
                       left_column="Admit", operator="<=", right_column="Discharge"),
    ]
    agent = AccuracyAgent()
    issues, stats = agent._evaluate_cross_field_rules(df, contract)
    by_rule = {}
    for issue in issues:
        rid = issue.evidence["rule_id"]
        by_rule[rid] = by_rule.get(rid, 0) + 1
    # Exactly one true violation per rule class; no lexicographic/TypeError storms.
    assert by_rule == {"max": 1, "order": 1}, by_rule
    assert stats["not_evaluable"] == 1  # 'not a date' excluded, not violated
    # Evidence-status separation on the run level:
    result = agent.run(df, contract, evidence_mode="CONTRACT_ONLY", reference_df=None, truth_manifest=None)
    assert result.metrics["confirmed_contract_violation_cells"] >= 1
    confirmed_cross_rows = [
        i for i in result.issues
        if i.issue_type == "cross_field_rule_violation" and i.evidence_status == "confirmed"
    ]
    candidate_cross_rows = [
        i for i in result.issues
        if i.issue_type == "cross_field_rule_violation" and i.evidence_status == "candidate"
    ]
    assert len(confirmed_cross_rows) == 1 and len(candidate_cross_rows) == 1
