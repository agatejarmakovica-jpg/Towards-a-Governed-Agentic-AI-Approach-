from __future__ import annotations

from cdqc_core.metrics import detection_metrics
from cdqc_core.models import Issue


def test_typed_coordinate_metrics_do_not_broadcast_column_scope():
    issues = [
        Issue("i1", "schema_metadata_gap", "column", "A", None, None, "confirmed", 1.0, 1.0),
        Issue("i2", "explicit_missingness", "cell", "B", 2, None, "confirmed", 1.0, 1.0),
    ]
    truth = [
        {"issue_type": "schema_metadata_gap", "scope": "column", "row_index": None, "column": "A"},
        {"issue_type": "explicit_missingness", "scope": "cell", "row_index": 2, "column": "B"},
    ]
    metrics = detection_metrics(issues, truth)
    assert metrics["precision"] == 1.0
    assert metrics["recall"] == 1.0
    assert metrics["f1"] == 1.0
