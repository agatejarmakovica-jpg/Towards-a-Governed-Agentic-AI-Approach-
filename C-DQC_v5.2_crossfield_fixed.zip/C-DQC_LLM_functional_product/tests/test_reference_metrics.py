from __future__ import annotations

import pandas as pd

from cdqc_core.metrics import exact_reference_metrics


def test_reference_metrics_count_wrong_cells_exactly():
    input_df = pd.DataFrame({"A": [1, 999, 3], "B": ["x", "y", "bad"]})
    reference_df = pd.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
    metrics = exact_reference_metrics(input_df, reference_df)
    assert metrics["wrong_cells"] == 2
    assert metrics["total_cells"] == 6
    assert abs(metrics["exact_cell_accuracy"] - 4 / 6) < 1e-12
