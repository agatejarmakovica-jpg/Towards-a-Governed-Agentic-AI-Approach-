from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from cdqc_core.contract import Approval, ColumnContract, DatasetContract, DatasetMetadata, save_contract
from cdqc_core.pipeline import apply_human_review, run_assessment
from cdqc_core.utils import sha256_file


def _approved_date_contract() -> DatasetContract:
    return DatasetContract(
        dataset_id="date_demo",
        approval=Approval(
            status="approved",
            approved_by="Data owner",
            approved_at_utc="2026-07-05T00:00:00+00:00",
        ),
        dataset_metadata=DatasetMetadata(
            title="Date demo",
            description="Test dataset",
            provenance="Unit test",
            version="1.0",
            license="Test",
            intended_reuse="Testing",
            privacy_status="No direct identifiers",
        ),
        columns={
            "Visit Date": ColumnContract(
                role="date",
                description="Visit date",
                target_format="%Y-%m-%d",
                source_formats=["%d/%m/%Y"],
                allow_format_normalization=True,
                sensitivity="public",
            )
        },
    )


def test_named_human_approval_creates_separate_curated_copy(tmp_path: Path):
    df = pd.DataFrame({"Visit Date": ["2024-01-01", "02/01/2024"]})
    input_path = tmp_path / "input.csv"
    contract_path = tmp_path / "contract.json"
    assessment_dir = tmp_path / "assessment"
    review_output = tmp_path / "reviewed"
    df.to_csv(input_path, index=False)
    save_contract(contract_path, _approved_date_contract())
    original_hash = sha256_file(input_path)

    run_assessment(
        input_path,
        assessment_dir,
        config_path=contract_path,
        require_approved_contract=True,
        create_zip=False,
    )
    queue = pd.read_csv(assessment_dir / "review_queue.csv", keep_default_na=False)
    row = queue[queue["issue_type"] == "date_format_inconsistency"].index[0]
    queue.loc[row, "decision"] = "approve"
    queue.loc[row, "reviewer"] = "Data owner"
    review_path = tmp_path / "review.csv"
    queue.to_csv(review_path, index=False)

    result = apply_human_review(
        input_path,
        assessment_dir,
        review_path,
        review_output,
        create_zip=False,
    )

    assert sha256_file(input_path) == original_hash
    curated = pd.read_csv(review_output / "curated_dataset.csv")
    assert curated.loc[1, "Visit Date"] == "2024-01-02"
    assert result["manifest"]["source_file_modified"] is False
    assert result["manifest"]["applied_change_count"] == 1
    assert result["comparison"]["delta"]["accuracy_support"] > 0


def test_approved_change_requires_reviewer_name(tmp_path: Path):
    df = pd.DataFrame({"Visit Date": ["02/01/2024"]})
    input_path = tmp_path / "input.csv"
    contract_path = tmp_path / "contract.json"
    assessment_dir = tmp_path / "assessment"
    df.to_csv(input_path, index=False)
    save_contract(contract_path, _approved_date_contract())
    run_assessment(
        input_path,
        assessment_dir,
        config_path=contract_path,
        require_approved_contract=True,
        create_zip=False,
    )
    queue = pd.read_csv(assessment_dir / "review_queue.csv", keep_default_na=False)
    row = queue[queue["issue_type"] == "date_format_inconsistency"].index[0]
    queue.loc[row, "decision"] = "approve"
    queue.loc[row, "reviewer"] = ""
    review_path = tmp_path / "review.csv"
    queue.to_csv(review_path, index=False)

    with pytest.raises(ValueError, match="reviewer"):
        apply_human_review(
            input_path,
            assessment_dir,
            review_path,
            tmp_path / "reviewed",
            create_zip=False,
        )


def test_ambiguous_date_is_not_executable_without_approved_source_format(tmp_path: Path):
    df = pd.DataFrame({"Visit Date": ["02/01/2024"]})
    input_path = tmp_path / "input.csv"
    contract_path = tmp_path / "contract.json"
    assessment_dir = tmp_path / "assessment"
    df.to_csv(input_path, index=False)
    contract = _approved_date_contract()
    payload = contract.model_dump(mode="python")
    payload["columns"]["Visit Date"]["source_formats"] = []
    save_contract(contract_path, DatasetContract.model_validate(payload))
    run_assessment(
        input_path,
        assessment_dir,
        config_path=contract_path,
        require_approved_contract=True,
        create_zip=False,
    )
    queue = pd.read_csv(assessment_dir / "review_queue.csv", keep_default_na=False)
    proposal = queue[queue["issue_type"] == "date_format_inconsistency"].iloc[0]
    assert str(proposal["executable"]).casefold() == "false"
