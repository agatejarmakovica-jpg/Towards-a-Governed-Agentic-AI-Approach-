from __future__ import annotations

from pathlib import Path

import pandas as pd

from cdqc_core.agents import run_agentic_assessment
from cdqc_core.contract import Approval, ColumnContract, DatasetContract, DatasetMetadata


def test_candidate_findings_never_authorize_automatic_action():
    df = pd.DataFrame({"Measurement": [-999] * 12 + list(range(20, 108))})
    contract = DatasetContract(
        dataset_id="candidate_demo",
        approval=Approval(
            status="approved",
            approved_by="Owner",
            approved_at_utc="2026-07-05T00:00:00+00:00",
        ),
        dataset_metadata=DatasetMetadata(
            title="Candidate demo",
            description="Test",
            provenance="Unit test",
            version="1",
            license="Test",
            intended_reuse="Testing",
            privacy_status="No identifiers",
        ),
        columns={"Measurement": ColumnContract(role="numeric", description="Measurement")},
    )
    result = run_agentic_assessment(df, contract)
    candidates = [issue for issue in result["issues"] if issue.evidence_status == "candidate"]
    assert candidates
    assert all(issue.automatic_action_allowed is False for issue in candidates)


def test_direct_identifier_policy_blocks_ready_verdict():
    df = pd.DataFrame({"Email": ["a@example.com", "b@example.com"]})
    contract = DatasetContract(
        dataset_id="privacy_demo",
        approval=Approval(
            status="approved",
            approved_by="Owner",
            approved_at_utc="2026-07-05T00:00:00+00:00",
        ),
        dataset_metadata=DatasetMetadata(
            title="Privacy demo",
            description="Test",
            provenance="Unit test",
            version="1",
            license="Test",
            intended_reuse="Testing",
            privacy_status="Contains direct identifiers; restricted access",
        ),
        columns={
            "Email": ColumnContract(
                role="email",
                description="Direct email identifier",
                sensitivity="direct_identifier",
                protected_from_change=True,
            )
        },
    )
    result = run_agentic_assessment(df, contract)
    assert result["quality_support_metrics"]["verdict"] == "NOT_READY"
    assert any("Direct identifier" in reason for reason in result["quality_support_metrics"]["verdict_reasons"])
