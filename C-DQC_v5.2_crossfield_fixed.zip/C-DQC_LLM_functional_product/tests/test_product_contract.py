from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from cdqc_core.contract import approve_contract, generate_draft_contract, save_contract
from cdqc_core.pipeline import run_assessment


def test_strict_mode_rejects_draft_contract(tmp_path: Path):
    df = pd.DataFrame({"A": [1, 2, 3]})
    input_path = tmp_path / "input.csv"
    contract_path = tmp_path / "contract.json"
    df.to_csv(input_path, index=False)
    save_contract(contract_path, generate_draft_contract(df, "demo"))

    with pytest.raises(ValueError, match="approved"):
        run_assessment(
            input_path,
            tmp_path / "out",
            config_path=contract_path,
            require_approved_contract=True,
            create_zip=False,
        )


def test_strict_mode_accepts_approved_contract_and_writes_product_outputs(tmp_path: Path):
    df = pd.DataFrame({"A": [1, 2, 3]})
    input_path = tmp_path / "input.csv"
    contract_path = tmp_path / "contract.json"
    output = tmp_path / "out"
    df.to_csv(input_path, index=False)
    contract = approve_contract(generate_draft_contract(df, "demo"), "Data owner")
    save_contract(contract_path, contract)

    result = run_assessment(
        input_path,
        output,
        config_path=contract_path,
        require_approved_contract=True,
        create_zip=False,
    )

    assert result["manifest"]["contract_status"] == "approved"
    assert (output / "agent_trace.json").exists()
    assert (output / "review_queue.csv").exists()
    assert (output / "report.html").exists()
    trace = json.loads((output / "agent_trace.json").read_text(encoding="utf-8"))
    assert [row["agent"] for row in trace] == [
        "IntakeStage",
        "CompletenessAgent",
        "AccuracyAgent",
        "ReuseAgent",
        "CoordinatorStage",
        "VerifierStage",
    ]
    assert result["manifest"]["scientific_agent_count"] == 3
    assert result["manifest"]["scientific_agents"] == [
        "CompletenessAgent", "AccuracyAgent", "ReuseAgent"
    ]
    assert trace[-1]["output_summary"]["passed"] is True
