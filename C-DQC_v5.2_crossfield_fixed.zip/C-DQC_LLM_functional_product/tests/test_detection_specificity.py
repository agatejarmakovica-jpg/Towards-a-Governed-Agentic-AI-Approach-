from __future__ import annotations

import pandas as pd

from cdqc_core.detectors import detect_issues


def test_declared_date_format_flags_only_nonconforming_cells():
    df = pd.DataFrame({"Visit Date": ["2024-01-02", "03/04/2024", "2024-05-06"]})
    config = {
        "columns": {
            "Visit Date": {
                "role": "date",
                "description": "date",
                "target_format": "%Y-%m-%d",
            }
        }
    }
    issues = detect_issues(df, config)
    flagged = [issue for issue in issues if issue.issue_type == "date_format_inconsistency"]
    assert [issue.row_index for issue in flagged] == [1]


def test_valid_zero_count_is_not_a_sentinel_without_distribution_gap():
    df = pd.DataFrame({"Prior Visits": [0] * 50 + [1] * 40 + [2] * 30 + [3] * 20})
    issues = detect_issues(df, {"columns": {"Prior Visits": {"role": "numeric", "description": "count"}}})
    assert not any(issue.issue_type == "disguised_missingness_candidate" for issue in issues)


def test_repeated_boundary_sentinel_is_detected_as_candidate():
    df = pd.DataFrame({"Measurement": [-999] * 12 + list(range(20, 108))})
    issues = detect_issues(df, {"columns": {"Measurement": {"role": "numeric", "description": "measurement"}}})
    sentinel = [issue for issue in issues if issue.issue_type == "disguised_missingness_candidate"]
    assert len(sentinel) == 12
    assert all(issue.evidence_status == "candidate" for issue in sentinel)
    assert all(issue.automatic_action_allowed is False for issue in sentinel)


def test_categorical_variant_flags_only_variant_cells():
    df = pd.DataFrame({"Gender": ["Female", "Female", " female ", "Male", "MALE"]})
    config = {"columns": {"Gender": {"role": "categorical", "description": "category", "allowed_values": ["Female", "Male"]}}}
    issues = detect_issues(df, config)
    rows = sorted(issue.row_index for issue in issues if issue.issue_type == "categorical_representation_inconsistency")
    assert rows == [2, 4]
